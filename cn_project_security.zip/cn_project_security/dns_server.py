import socket
import threading
import re
from dnslib import DNSRecord, RR, A

#  Shared key
KEY = b'secretkey'

#  XOR Encryption/Decryption
def xor_encrypt_decrypt(data):
    return bytes([b ^ KEY[i % len(KEY)] for i, b in enumerate(data)])

# SERVER CONFIGURATION
IP = "0.0.0.0"
PORT = 9090

# Local DNS database
dns_db = {
    "google.com.": "142.250.183.14",
    "example.com.": "93.184.216.34"
}

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.bind((IP, PORT))

print("Secure Custom DNS Server running...")

# Function to handle each client
def handle_client(data, addr):
    try:
        # Decrypt incoming data
        decrypted_data = xor_encrypt_decrypt(data)

        request = DNSRecord.parse(decrypted_data)
        domain = str(request.q.qname)

        print("Client requested:", domain)

        # Input validation
        if len(domain) > 100:
            print("Invalid: Domain too long")
            return

        if not re.match(r"^[a-zA-Z0-9.-]+\.$", domain):
            print("Invalid domain format")
            return

        #  Local resolution
        if domain in dns_db:
            print("Resolved from local DB")
            ip = dns_db[domain]

            reply = request.reply()
            reply.add_answer(RR(domain, rdata=A(ip)))

            #  Encrypt response
            encrypted_reply = xor_encrypt_decrypt(reply.pack())
            sock.sendto(encrypted_reply, addr)

        else:
            print("Forwarding to Google DNS...")

            forward = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            forward.settimeout(2)

            forward.sendto(decrypted_data, ("8.8.8.8", 53))
            response, _ = forward.recvfrom(512)

            #  Encrypt forwarded response
            encrypted_response = xor_encrypt_decrypt(response)
            sock.sendto(encrypted_response, addr)

    except Exception as e:
        print("Error:", e)

# Main loop with threading
while True:
    data, addr = sock.recvfrom(512)
    threading.Thread(target=handle_client, args=(data, addr)).start()