import socket
from dnslib import DNSRecord

#  Shared key
KEY = b'secretkey'

#  XOR Encryption/Decryption
def xor_encrypt_decrypt(data):
    return bytes([b ^ KEY[i % len(KEY)] for i, b in enumerate(data)])

server = ("127.0.0.1", 9090)

domain = input("Enter domain: ")

query = DNSRecord.question(domain)

#  Encrypt query
encrypted_query = xor_encrypt_decrypt(query.pack())

#  PROOF: Show encrypted query
print("Encrypted Query Sent:", encrypted_query)

sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
sock.sendto(encrypted_query, server)

data, _ = sock.recvfrom(512)

#  PROOF: Show encrypted response
print("Encrypted Response Received:", data)

# Decrypt response
decrypted_data = xor_encrypt_decrypt(data)

#  PROOF: Show decrypted data (partial)
print("Decrypted Data (first 50 bytes):", decrypted_data[:50])

response = DNSRecord.parse(decrypted_data)

if response.rr:
    print("IP Address:", response.rr[0].rdata)
else:
    print("No answer received")